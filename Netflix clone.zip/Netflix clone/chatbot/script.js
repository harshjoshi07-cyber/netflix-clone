const chatContainer = document.querySelector('.chat-container');
const userInputField = document.querySelector('#user-input-field');
const sendButton = document.querySelector('#send-button');
const userInputElement = document.querySelector('#user-input');
const botResponseElement = document.querySelector('#bot-response');

let conversationHistory = [];

sendButton.addEventListener('click', async () => {
    const userInput = userInputField.value.trim();
    if (userInput !== '') {
        userInputElement.textContent = userInput;
        userInputField.value = '';

        // Call the chatbot API to get the response
        const response = await getChatbotResponse(userInput);

        botResponseElement.textContent = response;
        conversationHistory.push({ user: userInput, bot: response });
    }
});

async function getChatbotResponse(userInput) {
    // Replace with your chatbot API endpoint
    const apiUrl = 'https://your-chatbot-api.com/api/answer';

    try {
        const response = await fetch(apiUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ input: userInput })
        });

        const data = await response.json();
        return data.answer;
    } catch (error) {
        console.error(error);
        return 'Sorry, I couldn\'t understand that. Please try again!';
    }
}